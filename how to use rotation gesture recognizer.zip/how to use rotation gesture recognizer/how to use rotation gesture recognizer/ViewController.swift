//
//  ViewController.swift
//  how to use rotation gesture recognizer
//
//  Created by Supine Hub Technologies Pvt. Ltd. on 31/03/20.
//  Copyright © 2020 Supine Hub Technologies Pvt. Ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var rotationgesture: UIRotationGestureRecognizer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func rotation(_ sender: Any) {
        guard let gestureview = rotationgesture.view else {
            return
        }
        gestureview.transform = gestureview.transform.rotated(by: rotationgesture.rotation)
        rotationgesture.rotation = 0
    }
    
}

